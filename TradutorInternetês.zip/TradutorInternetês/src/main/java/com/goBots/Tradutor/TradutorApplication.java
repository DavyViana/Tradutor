package com.goBots.Tradutor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradutorApplication.class, args);
	}

}
